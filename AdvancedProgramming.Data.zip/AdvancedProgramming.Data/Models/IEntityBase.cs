﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdvancedProgramming.Data.Models;

namespace AdvancedProgramming.Data.Models
{
    public interface IEntityBase
    {
        //Guid UniqueIdentifier { get; set; }
        int Id { get; set; }
    }

    public class EntityBase : IEntityBase
    {
        //public Guid UniqueIdentifier { get; set; }
        public int Id { get; set; }

    }
}
