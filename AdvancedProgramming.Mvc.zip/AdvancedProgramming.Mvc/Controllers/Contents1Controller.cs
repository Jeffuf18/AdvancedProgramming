﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AdvancedProgramming.Data;
using AdvancedProgramming.Business;


namespace AdvancedProgramming.Mvc.Controllers
{
    public class Contents1Controller : Controller
    {
        private MediaStoreEntities db = new MediaStoreEntities();

        // GET: Contents1
        public ActionResult Index()
        {
            var contents = db.Contents.Include(c => c.ContentType).Include(c => c.MediaUser);
            return View(contents.ToList());
        }

        // GET: Contents1/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Content content = db.Contents.Find(id);
            if (content == null)
            {
                return HttpNotFound();
            }
            return View(content);
        }

        // GET: Contents1/Create
        public ActionResult Create()
        {
            ViewBag.ContentTypeId = new SelectList(db.ContentTypes, "Id", "Name");
            ViewBag.UserId = new SelectList(db.MediaUsers, "Id", "Username");
            return View();
        }

        // POST: Contents1/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Title,Description,Url,ContentTypeId,UserId,CreatedAt")] Content content)
        {
            if (ModelState.IsValid)
            {
                db.Contents.Add(content);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ContentTypeId = new SelectList(db.ContentTypes, "Id", "Name", content.ContentTypeId);
            ViewBag.UserId = new SelectList(db.MediaUsers, "Id", "Username", content.UserId);
            return View(content);
        }

        // GET: Contents1/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Content content = db.Contents.Find(id);
            if (content == null)
            {
                return HttpNotFound();
            }
            ViewBag.ContentTypeId = new SelectList(db.ContentTypes, "Id", "Name", content.ContentTypeId);
            ViewBag.UserId = new SelectList(db.MediaUsers, "Id", "Username", content.UserId);
            return View(content);
        }

        // POST: Contents1/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Description,Url,ContentTypeId,UserId,CreatedAt")] Content content)
        {
            if (ModelState.IsValid)
            {
                db.Entry(content).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ContentTypeId = new SelectList(db.ContentTypes, "Id", "Name", content.ContentTypeId);
            ViewBag.UserId = new SelectList(db.MediaUsers, "Id", "Username", content.UserId);
            return View(content);
        }

        // GET: Contents1/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Content content = db.Contents.Find(id);
            if (content == null)
            {
                return HttpNotFound();
            }
            return View(content);
        }

        // POST: Contents1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Content content = db.Contents.Find(id);
            db.Contents.Remove(content);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
