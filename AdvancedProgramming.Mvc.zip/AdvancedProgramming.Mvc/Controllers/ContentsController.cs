﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdvancedProgramming.Mvc.Controllers
{
    public class ContentsController
    {

    

    public ActionResult Create ()
        {
            ViewBag.ContentTypeId = new SelectList(_contentTypeBusiness.GetAll(), "Id", "Name");
            ViewBag.UserId = new SelectList(_mediaUserBusiness.GetAll(), "Id", "UserName");
            return ViewContext();
        }
}
     }