﻿using AdvancedProgramming.Data;
using AdvancedProgramming.Data.Models;
using AdvancedProgramming.Repository;

namespace AdvancedProgramming.Business
{
    public class BusinessManager<T> where T : IEntityBase, new()
    {
        private readonly IRepositoryBase<T> repository;
        public BusinessManager()
        {
            repository = new RepositoryBase<T>();
        }
    }

}
