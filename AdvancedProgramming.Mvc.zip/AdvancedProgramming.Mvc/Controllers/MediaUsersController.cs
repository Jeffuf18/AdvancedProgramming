﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AdvancedProgramming.Data;
using AdvancedProgramming.Business;


namespace AdvancedProgramming.Mvc.Controllers
{
    public class MediaUsersController : Controller
    {
        private MediaStoreEntities db = new MediaStoreEntities();

        // GET: MediaUsers
        public ActionResult Index()
        {
            return View(db.MediaUsers.ToList());
        }

        // GET: MediaUsers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MediaUser mediaUser = db.MediaUsers.Find(id);
            if (mediaUser == null)
            {
                return HttpNotFound();
            }
            return View(mediaUser);
        }

        // GET: MediaUsers/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MediaUsers/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Username,Email")] MediaUser mediaUser)
        {
            if (ModelState.IsValid)
            {
                db.MediaUsers.Add(mediaUser);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(mediaUser);
        }

        // GET: MediaUsers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MediaUser mediaUser = db.MediaUsers.Find(id);
            if (mediaUser == null)
            {
                return HttpNotFound();
            }
            return View(mediaUser);
        }

        // POST: MediaUsers/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Username,Email")] MediaUser mediaUser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(mediaUser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(mediaUser);
        }

        // GET: MediaUsers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MediaUser mediaUser = db.MediaUsers.Find(id);
            if (mediaUser == null)
            {
                return HttpNotFound();
            }
            return View(mediaUser);
        }

        // POST: MediaUsers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            MediaUser mediaUser = db.MediaUsers.Find(id);
            db.MediaUsers.Remove(mediaUser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
