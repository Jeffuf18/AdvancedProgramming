﻿USE [MediaStore]
GO
/****** Object:  Table [dbo].[Content]    Script Date: 6/23/2025 10:50:56 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Content](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](255) NOT NULL,
	[Description] [text] NULL,
	[Url] [varchar](500) NULL,
	[ContentTypeId] [int] NULL,
	[UserId] [int] NULL,
	[CreatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ContentType]    Script Date: 6/23/2025 10:50:56 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ContentType](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MediaUser]    Script Date: 6/23/2025 10:50:56 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MediaUser](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Username] [varchar](50) NOT NULL,
	[Email] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Content] ON 
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (1, N'Sunset Beach', N'A beautiful sunset over the ocean.', N'https://example.com/sunset.jpg', 1, 1, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (2, N'Tech News Today', N'Latest updates on AI and tech industry.', N'https://example.com/tech-news', 2, 2, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (3, N'Daily RSS Feed', N'Top stories for today.', N'https://example.com/rss.xml', 3, 3, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (4, N'Buy One Get One Free', N'Special offer on summer collection.', N'https://example.com/ads/bogo', 4, 1, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (5, N'Funny Cat Meme', N'A hilarious cat meme.', N'https://example.com/memes/cat.jpg', 5, 2, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (6, N'Breaking News: Market Crash', N'Stock market sees a sudden dip.', N'https://example.com/news/market-crash', 2, 3, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (7, N'Trending: Viral Dance Challenge', N'New dance trend going viral.', N'https://example.com/trending/dance', 6, 1, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (8, N'New Smartphone Released', N'Features and specs of the latest smartphone.', N'https://example.com/news/smartphone', 2, 2, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (9, N'Hilarious Dog Video', N'A funny dog doing tricks.', N'https://example.com/memes/dog.mp4', 5, 3, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (10, N'Super Bowl Commercial', N'Best commercials from Super Bowl.', N'https://example.com/ads/superbowl', 4, 1, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (11, N'RSS: Sports Highlights', N'Daily sports updates.', N'https://example.com/rss/sports', 3, 2, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (12, N'Travel Vlog', N'Explore the best travel destinations.', N'https://example.com/travel-vlog', 1, 3, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (13, N'Fashion Trends 2025', N'Upcoming fashion styles.', N'https://example.com/news/fashion', 2, 1, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (14, N'Meme Compilation', N'Top 10 memes of the week.', N'https://example.com/memes/compilation', 5, 2, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (15, N'Political Debate Highlights', N'Key moments from last night’s debate.', N'https://example.com/news/politics', 2, 3, CAST(N'2025-03-23T16:43:05.217' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (16, N'Amazing Landscape', N'A breathtaking mountain view.', N'https://example.com/images/mountain.jpg', 1, 1, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (17, N'Breaking Science Discovery', N'New breakthrough in physics.', N'https://example.com/news/science', 2, 2, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (18, N'Daily Tech RSS', N'Latest updates in the tech world.', N'https://example.com/rss/tech', 3, 3, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (19, N'Holiday Discounts', N'Exclusive holiday season discounts.', N'https://example.com/ads/holiday', 4, 1, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (20, N'Classic Meme Revival', N'A nostalgic meme making a comeback.', N'https://example.com/memes/classic.jpg', 5, 2, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (21, N'Celebrity Gossip', N'Latest celebrity news and rumors.', N'https://example.com/news/celebs', 2, 3, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (22, N'Fitness Trends', N'New workout techniques for 2025.', N'https://example.com/trending/fitness', 6, 1, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (23, N'Space Exploration', N'Updates on Mars mission.', N'https://example.com/news/space', 2, 2, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (24, N'Viral Dog Challenge', N'A new dog trick going viral.', N'https://example.com/memes/dogchallenge.mp4', 5, 3, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (25, N'Supermarket Mega Sale', N'Huge discounts on groceries.', N'https://example.com/ads/sale', 4, 1, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (26, N'RSS: Health & Wellness', N'Daily health tips.', N'https://example.com/rss/health', 3, 2, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (27, N'Underwater Photography', N'Stunning shots from the ocean.', N'https://example.com/images/underwater.jpg', 1, 3, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (28, N'Gaming Industry Updates', N'Latest in video games.', N'https://example.com/news/gaming', 2, 1, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (29, N'Viral TikTok Trend', N'A new social media sensation.', N'https://example.com/trending/tiktok', 6, 2, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (30, N'Startup Success Stories', N'Inspiring entrepreneur journeys.', N'https://example.com/news/startups', 2, 3, CAST(N'2025-03-23T16:43:05.220' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (31, N'Beautiful Waterfall', N'A mesmerizing waterfall in the forest.', N'https://example.com/images/waterfall.jpg', 1, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (32, N'AI Breakthrough', N'New AI model surpasses human intelligence.', N'https://example.com/news/ai-breakthrough', 2, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (33, N'Fitness RSS', N'Daily workout and nutrition tips.', N'https://example.com/rss/fitness', 3, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (34, N'Flash Sale Alert', N'Limited time discounts on electronics.', N'https://example.com/ads/flash-sale', 4, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (35, N'New Meme Alert', N'A trending meme making everyone laugh.', N'https://example.com/memes/new.jpg', 5, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (36, N'Cryptocurrency Update', N'Bitcoin surges to new highs.', N'https://example.com/news/crypto', 2, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (37, N'Music Festival Highlights', N'Top moments from the weekend festival.', N'https://example.com/trending/music', 6, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (38, N'SpaceX Mars Mission', N'New updates on Mars colonization plans.', N'https://example.com/news/mars-mission', 2, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (39, N'Adorable Puppy Video', N'A cute puppy playing in the park.', N'https://example.com/memes/puppy.mp4', 5, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (40, N'Black Friday Deals', N'Biggest discounts of the year.', N'https://example.com/ads/black-friday', 4, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (41, N'Tech Gadget Review', N'Latest review on cutting-edge gadgets.', N'https://example.com/news/gadgets', 2, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (42, N'Yoga and Meditation', N'Tips for a healthier lifestyle.', N'https://example.com/rss/wellness', 3, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (43, N'Stunning Cityscape', N'A beautiful skyline at night.', N'https://example.com/images/city.jpg', 1, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (44, N'Streaming Wars', N'New battle between streaming giants.', N'https://example.com/news/streaming', 2, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (45, N'Hiking Adventure', N'Best hiking trails in the world.', N'https://example.com/trending/hiking', 6, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (46, N'AI in Healthcare', N'How AI is transforming medicine.', N'https://example.com/news/ai-healthcare', 2, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (47, N'Amazing Space Images', N'High-resolution images from NASA.', N'https://example.com/images/space.jpg', 1, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (48, N'Cybersecurity Trends', N'Latest developments in cybersecurity.', N'https://example.com/news/cybersecurity', 2, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (49, N'Vegan Recipes RSS', N'Healthy and delicious vegan recipes.', N'https://example.com/rss/vegan', 3, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (50, N'Exclusive Brand Offers', N'Limited-time brand promotions.', N'https://example.com/ads/brand-offers', 4, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (51, N'New Meme Sensation', N'Another meme taking the internet by storm.', N'https://example.com/memes/sensation.jpg', 5, 2, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (52, N'Stock Market Updates', N'Daily insights into stock performance.', N'https://example.com/news/stocks', 2, 3, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
INSERT [dbo].[Content] ([Id], [Title], [Description], [Url], [ContentTypeId], [UserId], [CreatedAt]) VALUES (53, N'Social Media Trends', N'What’s trending on social platforms.', N'https://example.com/trending/social', 6, 1, CAST(N'2025-03-23T16:43:05.227' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Content] OFF
GO
SET IDENTITY_INSERT [dbo].[ContentType] ON 
GO
INSERT [dbo].[ContentType] ([Id], [Name]) VALUES (4, N'Ad')
GO
INSERT [dbo].[ContentType] ([Id], [Name]) VALUES (1, N'Image')
GO
INSERT [dbo].[ContentType] ([Id], [Name]) VALUES (5, N'Meme')
GO
INSERT [dbo].[ContentType] ([Id], [Name]) VALUES (2, N'News')
GO
INSERT [dbo].[ContentType] ([Id], [Name]) VALUES (3, N'RSS')
GO
INSERT [dbo].[ContentType] ([Id], [Name]) VALUES (6, N'Trending Post')
GO
SET IDENTITY_INSERT [dbo].[ContentType] OFF
GO
SET IDENTITY_INSERT [dbo].[MediaUser] ON 
GO
INSERT [dbo].[MediaUser] ([Id], [Username], [Email]) VALUES (1, N'john_doe', N'john@example.com')
GO
INSERT [dbo].[MediaUser] ([Id], [Username], [Email]) VALUES (2, N'jane_smith', N'jane@example.com')
GO
INSERT [dbo].[MediaUser] ([Id], [Username], [Email]) VALUES (3, N'admin', N'admin@content.com')
GO
SET IDENTITY_INSERT [dbo].[MediaUser] OFF
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__ContentT__737584F6362CFCB0]    Script Date: 6/23/2025 10:50:56 AM ******/
ALTER TABLE [dbo].[ContentType] ADD UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__MediaUse__536C85E41E7E7833]    Script Date: 6/23/2025 10:50:56 AM ******/
ALTER TABLE [dbo].[MediaUser] ADD UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__MediaUse__A9D105344748B1D9]    Script Date: 6/23/2025 10:50:56 AM ******/
ALTER TABLE [dbo].[MediaUser] ADD UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Content] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Content]  WITH CHECK ADD FOREIGN KEY([ContentTypeId])
REFERENCES [dbo].[ContentType] ([Id])
GO
